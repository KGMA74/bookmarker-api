package com.learning.bookmarker_api.domain;

import com.learning.bookmarker_api.adapter.`in`.rest.PaginatedResponse
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.stereotype.Repository
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController


//@Repository
interface BookmarkRepository: JpaRepository<Bookmark, Long> {

    @Query(
        "SELECT new com.learning.bookmarker_api.domain.BookmarkDTO(b.title, b.url) FROM Bookmark b"
    )
    fun findAllBookmarks(pageable: Pageable): Page<BookmarkDTO>

    @Query("""
        SELECT new com.learning.bookmarker_api.domain.BookmarkDTO(b.title, b.url) FROM Bookmark b
        WHERE lower(b.title) like lower(concat('%', :query, '%')) 
    """)
    fun searchBookmarks(query: String, pageable: Pageable): Page<BookmarkDTO>
}